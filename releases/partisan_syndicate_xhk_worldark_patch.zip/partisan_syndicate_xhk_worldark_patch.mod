name="Синдикат Сопротивления — патч для XHK World Ark"
version="1.0"
tags={
	"Gameplay"
}
dependencies={
	"Синдикат Сопротивления / Partisan Syndicate"
	"[4.5] XHK World Ark"
}
supported_version="v4.5.*"
path="mod/partisan_syndicate_xhk_worldark_patch"
