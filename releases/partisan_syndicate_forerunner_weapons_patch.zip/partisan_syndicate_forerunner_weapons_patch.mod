name="Синдикат Сопротивления — патч: оружие Предтеч"
version="1.0"
tags={
	"Gameplay"
	"Military"
}
dependencies={
	"Синдикат Сопротивления / Partisan Syndicate"
}
supported_version="v4.*"
path="mod/partisan_syndicate_forerunner_weapons_patch"
