name="Синдикат Сопротивления — патч окна стоянки (без UIOD)"
version="1.0"
tags={
	"Interface"
}
dependencies={
	"Синдикат Сопротивления / Partisan Syndicate"
}
supported_version="v4.5.*"
path="mod/partisan_syndicate_vanilla_ui_patch"
